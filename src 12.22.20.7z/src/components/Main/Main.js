import React from "react";

import Header from "../Header/Header";
import Preloader from "../Preloader/Preloader";
import NothingFound from "../NothingFound/NothingFound";
import NewsCardsList from "../NewsCardsList/NewsCardsList";
import About from "../About/About";

function Main(props) {
  const [errorMessage, setErrorMessage] = React.useState("");
  const inputRef = React.createRef();

  function onSubmit(e) {
    e.preventDefault();
    if (inputRef.current.value.length === 0) {
      setErrorMessage("Please enter keyword");
    } else {
      setErrorMessage("");
      props.onSearch();
    }
  }

  return (
    <>
      <div className="main">
        <Header
          isPopupOpened={props.isPopupOpened}
          closePopups={props.closePopups}
          onLogout={props.onLogout}
          onSignInClick={props.onSignInClick}
          isLoggedIn={props.isLoggedIn}
          onSavedArticlesClick={props.onSavedArticlesClick}
        />

        <div className="main__title-container">
          <h1 className="main__title">What's going on in the world?</h1>
          <p className="main__subtitle">
            Find the latest news on any topic and save them in your personal
            account.
          </p>
        </div>
        <div className="main__search-container">
          <form action="" className="main__search-form" onSubmit={onSubmit}>
            <input
              ref={inputRef}
              onChange={(e) => {
                console.log(inputRef.current.value);

                props.onInputQueryChange(e);
              }}
              type="text"
              className="main__search-input"
              placeholder="Enter topic"
            />

            <button className="main__search-button">Search</button>
          </form>
            <span>{errorMessage}</span>
        </div>
      </div>

      {props.isSearching && <Preloader />}
      {props.noArticlesFound && <NothingFound />}

      {props.data.length > 0 && (
        <NewsCardsList
          data={props.data}
          isLoggedIn={props.isLoggedIn}
          savedArticles={props.savedArticles}
          onSaveArticle={(article) => {
            props.onSaveArticle(article);
          }}
          onDeleteSavedArticle={(article) => {
            props.onDeleteSavedArticle(article);
          }}
        />
      )}

      <About />
    </>
  );
}

export default Main;
